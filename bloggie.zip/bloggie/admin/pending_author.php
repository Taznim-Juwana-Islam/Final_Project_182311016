<?php
$page_id=101;
$page_tittle ="Pending author";
include 'admin-header.php';
?>

<div class="container-fluid">
  <div class="page_tittle p-1 pl-3 mt-4">
    <h4><?php echo $page_tittle?></h4>
  </div>
</div>

<!-- content starts here  -->

















<?php include 'admin-footer.php'; ?>